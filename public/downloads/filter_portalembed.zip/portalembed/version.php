<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'filter_portalembed';
$plugin->version = 2026090101;
$plugin->requires = 2022041900;
$plugin->maturity = MATURITY_STABLE;
$plugin->release = '1.1.2';
